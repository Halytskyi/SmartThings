# pcfan
This Arduino library allows monitoring of the speed of a PC fan.

See project at https://www.hackster.io/porrey/use-a-pc-fan-as-a-sensor-265798.
